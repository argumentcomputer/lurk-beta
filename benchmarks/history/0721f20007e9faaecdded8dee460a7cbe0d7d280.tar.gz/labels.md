gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,7bfa40f15860c-23-12-12
