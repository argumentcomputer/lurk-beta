gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,95f97612d1216-23-12-11
