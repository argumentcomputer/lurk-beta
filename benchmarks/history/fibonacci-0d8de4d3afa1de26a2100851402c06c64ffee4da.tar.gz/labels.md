gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,5efd7b7aa0c0b-24-02-22
