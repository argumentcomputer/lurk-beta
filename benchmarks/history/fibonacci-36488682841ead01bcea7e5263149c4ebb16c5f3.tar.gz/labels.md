gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,5e3678d16bb0d-24-01-31
