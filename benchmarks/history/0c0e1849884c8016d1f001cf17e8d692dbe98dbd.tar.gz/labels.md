gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,e1a8971eb0d7e-23-12-18
