gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,9c919e75d2eaa-24-02-21
