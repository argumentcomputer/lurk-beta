gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,8f39395eb2fbd-24-01-05
