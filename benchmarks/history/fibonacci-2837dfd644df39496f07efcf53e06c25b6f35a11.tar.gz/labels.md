gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,d482475303835-24-02-22
