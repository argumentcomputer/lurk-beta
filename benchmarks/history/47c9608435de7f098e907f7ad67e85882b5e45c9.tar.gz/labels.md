gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,ef2acd5e3b1b5-23-11-23
