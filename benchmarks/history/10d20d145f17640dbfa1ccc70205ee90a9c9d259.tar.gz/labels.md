linux,x64,gpu,gpu-bench,huitseeker
