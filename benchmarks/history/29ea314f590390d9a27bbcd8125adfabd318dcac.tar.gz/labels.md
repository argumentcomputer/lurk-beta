gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,444670d49e3de-24-01-12
