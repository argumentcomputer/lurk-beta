gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,c6ea3f4a4c1bd-24-02-09
