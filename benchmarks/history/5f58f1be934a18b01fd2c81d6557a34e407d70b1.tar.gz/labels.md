gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,d6a293452a6a6-23-11-20
