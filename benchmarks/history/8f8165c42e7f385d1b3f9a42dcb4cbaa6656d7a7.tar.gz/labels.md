gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,bc66cb96eb726-23-12-21
