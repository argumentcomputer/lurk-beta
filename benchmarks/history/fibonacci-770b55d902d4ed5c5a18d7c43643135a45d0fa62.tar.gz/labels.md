gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,3d9687ccf3ebc-24-03-08
