gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,b3ae71df394fb-24-01-09
