gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,8bd983efbe47f-23-12-19
