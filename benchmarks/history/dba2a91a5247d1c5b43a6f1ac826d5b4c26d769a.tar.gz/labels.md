gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,7a2d38f3bd44b-24-01-11
