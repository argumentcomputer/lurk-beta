gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,8df8441eaea0c-24-01-22
