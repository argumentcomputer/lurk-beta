gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,50750f8245761-24-02-16
