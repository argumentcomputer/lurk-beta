gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,975cfe7a90ace-23-12-11
