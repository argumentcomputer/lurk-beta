gpu-bench,gh-pages,Linux,x86_64,gpu,NVIDIA L4,8e4fedc7454fe-24-04-15
